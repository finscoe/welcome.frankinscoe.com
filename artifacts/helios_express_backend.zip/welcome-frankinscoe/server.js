const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

// Handle form submissions
app.post('/submit', (req, res) => {
    const { name, email, services } = req.body;

    console.log('New Access Request:');
    console.log(`Name: ${name}`);
    console.log(`Email: ${email}`);
    console.log(`Services Requested: ${services}`);

    res.send(`
    <h2>Thanks, ${name}!</h2>
    <p>Your request to access HELIOS has been received.</p>
    <p><a href="/">Go back</a></p>
  `);
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
