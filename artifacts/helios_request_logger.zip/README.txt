HELIOS Request Logger (Database Enhancement)
--------------------------------------------
This is a simple SQLite-backed service request logger for user submissions made through the welcome.frankinscoe.com website.

- The script connects to a SQLite database `request_logger.db`.
- It creates a `service_requests` table if it does not already exist.
- New service requests can be added via the `add_request` function.
- Parameterized queries are used to protect against SQL injection.

Run:
    python request_logger.py