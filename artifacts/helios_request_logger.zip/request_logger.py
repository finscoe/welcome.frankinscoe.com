import sqlite3

def add_request(user, request_type, request_description):
    conn = sqlite3.connect('request_logger.db')
    c = conn.cursor()
    c.execute('''
        INSERT INTO service_requests (user, request_type, request_description)
        VALUES (?, ?, ?)
    ''', (user, request_type, request_description))
    conn.commit()
    conn.close()
    print("Request added successfully!")

# Example usage
if __name__ == "__main__":
    add_request('johndoe', 'Nextcloud', 'Access to Nextcloud requested.')
    add_request('janedoe', 'Plex', 'Request to add new media to Plex library.')